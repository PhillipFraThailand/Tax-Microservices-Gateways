// phillip eismark
// imports
const axios = require('axios');
const sqlite3 = require('sqlite3');
const express = require('express');

// instantiate database
var db = new sqlite3.Database('/Users/phillipeismark/Documents/SystemIntegration/si_mandatory_assignment_2/Skat/Database/TaxInfoDb.sqlite');

// port
const PORT = 8088;

// create express application
var app = express();

// setup express to use json
app.use(express.json());

// index for testing
app.get('/', (req, res) => {
    console.log('Received request on "/"')
    res.status(200).send({'Response': 'Welcome to SkatAPI, we use JSON here :)'});
});

// create user
app.post('/create-user', (req, res) => {
    console.log('create-user request');
    let data = req.body;
    let query = 'INSERT INTO SkatUser(UserId, CreatedAt, IsActive) VALUES(?,?,?)';
    db.run(query, [data.UserId, data.CreatedAt, data.IsActive], (err) => {
        if (err) {
            console.log(err);
            res.status(500).send({'Response':'Error creating user'});
        } 
        else {
            res.status(201).send({'Response':'Succes creating user'});
        };
    });
});

// get specific user
app.get('/get-user', (req, res) => {
    console.log('received request on "/get-user"');
    let data = req.body;
    let query = 'SELECT * FROM SkatUser WHERE Id = ?';
    db.get(query, [data.Id], (err, user) => {
        if (err) {
            console.log(err);
            res.status(500).send({'Response':'Error getting user'});
        } 
            else {
            res.status(200).send({'Response':user});
        };
    });
});

// update specific user
app.patch('/update-user', (req, res) => {
    console.log('received request on "/update-user"');
    let data = req.body;
    let query = `UPDATE SkatUser SET ${data.Column} = ${data.Value} WHERE ${data.Condition} = ${data.ConditionValue}`;
    db.run(query, (err) => {
        if (err) {
            console.log(err);
            res.status(500).send({'Response':'Error updating user'});
        } else {
            res.status(200).send({'Response': 'Success updating'});
        };
    });
});

//delete specific user
app.delete('/delete-user', (req, res) => {
    console.log('received request on "/delete-user"');
    let data = req.body;
    let query = 'DELETE From SkatUser WHERE Id = ?';
    db.run(query, [data.Id], (err) => {
        if (err) {
            console.log(err);
            res.status(500).send({"Response":"Error deleting user"});
        } else {
            res.status(200).send({"Response": "OK Deleted"});
        };
    }); 
});

// CRUD SkatYear : createasmanyentriesintheSkatUserYearTableasthereare SkatUsers
// create SkatYear
app.post('/create-skatyear', (req, res) => {
    console.log('received request on "/create-skatyear"');
    let data = req.body;
    let query = 'INSERT INTO SkatYear(Label, CreatedAt, ModifiedAt, StartDate, EndDate) VALUES(?,?,?,?,?)';
    db.run(query, [data.Label, data.CreatedAt, data.ModifiedAt, data.StartDate, data.EndDate], (err) => {
        if (err) {
            console.log(err);
            res.status(500).send({'Response':'Error creating SkatYear'});
        } 
        else {
            res.status(201).send({'Response':'Succes creating SkatYear'});
        };
    });
});

// get skatyear
app.get('/get-skatyear', (req,res) => {
    console.log('received request on "/get-skatyear"');
        let data = req.body;
        let query = 'SELECT * FROM SkatUser WHERE Id = ?';
        db.get(query, [data.Id], (err, row) => {
            if (err) {
                console.log(err);
                res.status(500).send({'Response':'Error getting SkatYear'});
            } 
            else {
                res.status(200).send({'Response':row});
            };
    });
});

// update specific user
app.patch('/update-skatyear', (req, res) => {
    console.log('received request on "/skatyear"');
    let data = req.body;
    let query = `UPDATE SkatYear SET ${data.Column} = ${data.Value} WHERE ${data.Condition} = ${data.ConditionValue}`;
    console.log(query)
    db.run(query, (err) => {
        if (err) {
            console.log(err);
            res.status(500).send({'Response':'Error updating SkatYear'});
        } else {
            res.status(200).send({'Response': 'Success updating SkatYear'});
        };
    });
});

// delete skatYear
app.delete('/delete-skatyear', (req, res) => {
    console.log('received request on "/delete-skatyear"');
    let data = req.body;
    let query = 'DELETE From SkatYear WHERE Id = ?';
    db.run(query, [data.Id], (err) => {
        if (err) {
            console.log(err);
            res.status(500).send({"Response":"Error deleting SkatYear"});
        } else {
            res.status(200).send({"Response": "OK Deleted SkatYear"});
        };
    }); 
});

// pay taxes NOTE: i should break this into functions. So switch check as a function and updateing skatYear
app.post('/pay-taxes', (req, res) => {
    console.log('received request on "/pay-taxes"');
    let data = req.body;
    let query = 'Select * from SkatUserYear WHERE IsPaid = 0 and UserId = ?';

    // verify valid amount
    if (data.Amount <= 0) {
        console.log('Invalid amount');
        res.status(400).send({"Response":"Invalid Amount must be over 0"});
    } else {
        // look for unpaid taxyears. results array should be 0 if there are none.
        db.all(query, [data.UserId], (err, results) => {
            if (err) {
                console.log(err);
                res.status(500).send({"Response":"Error checking earlier tax years"});
            } else {
                switch (results.length) {
                    case 0:
                        console.log('found zero unpaid taxyears');
                    break;

                    case results.length >= 1:
                        console.log('found unpaid taxyears');
                    break;

                    default:
                        console('unhandled case');
                    break;
                }
            }
        });
        
    //after notifying about earlier taxyears
    //request Skat_Tax_Calculator function. 
    console.log('Sending axios request to tax-calculater');
    
    // the calculator looks for 'money'
    axios.post('http://localhost:7071/api/Skat_Tax_Calculator', {
        money: `${data.money}`
    })
    // catch response and request to deduce the amount from the users account
    .then((response) => {
            //make the request if statuscode is invalid
            if (response.status < 400) {
                axios.get('localhost:5005/update_account', {
                    data: {
                        Id: data.UserId,
                        Set: Amount,
                        Amount:response.data.tax_money
                    }                    
                })
                // use response from the bank
                .then((response) => {
                    console.log('response from bank: ', response.data);
                    // if the bank returns success we <update the IsPaid because we know that the amount has been deducted
                    if (response.status < 400) {
                        let query = `UPDATE SkatYear SET IsPaid = 1 WHERE UserId = ${data.UserId}`;   // we should also check for the 
                        res.status.send({"Response": response});                                      // exact year to update but its fine for the assignment
                    } else {
                        console.log('unexpected statuscode');
                    }
                })
                .catch(function (error) {
                    console.log(error);
                })
                .then(()=>{
                    console.log('then block which always runs')
                });
            } else {
                console.log('Invalid response from bank: ', response.status);
            }
        });
    }
});

// start sever on port
app.listen(PORT, (err) => {
    if (err) {
        console.log('There was an error starting the server: ', err);
        return;
    } else {
        console.log('Listening on port: ', PORT);
    }
});